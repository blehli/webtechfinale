Our course website project is working using the wamp server.

1. Open the WAMP server
2. Copy 9331A-G6 in the folder directory C:\wamp64\www
3. Open phpMyAdmin in the wamp server
4. Import our database SQL file from 9331A-G6\website\database
5. Open your localhost in the browser
6. Open the website folder in the localhost by accessing localhost/www/9331A-G6/website