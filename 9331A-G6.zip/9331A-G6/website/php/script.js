

function notify() {
    new Notification ("Notification! ", {
        icon: "./pictures/LOGO.png",
        body: "There is an available Quiz at this topic! :)"
    };
}
